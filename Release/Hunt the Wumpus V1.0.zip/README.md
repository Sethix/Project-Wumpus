# Project-Wumpus

This is my recreation of Hunt the Wumpus.


It's simple and I put about 9 hours into it. This is my second game in C++ with graphics, third game over-all.

___
#Instructions

Input one of the keywords presented to you (or the first letter of it) to do that action.


The goal is to kill the wumpus before you die or run out of arrows!

___
#Credits

Created by Justin Hamm


Original by Gregory Yob in 1972

___
#Post-Mortem


I spent about 5 hours programming the string class used in this project and 4 hours researching.


Coming from C# I'm not used to dealing with memory management too much so it was interesting for me.


On the game itself I did it over the course of two days, in a total of about 8 hours, give or take. There were plenty of moments where I zoned out.


It uses the SFML library which I had to compile when I made space invaders due to the lack of a VS2015 version.


I think some points I should focus on is planning ahead. I spent a lot of time re-writing code because I didn't like the way I did things. There are still things I would change to make it neater, but it's not important.


Even adding graphics is outside the scope of this simple text based adventure. That's why the graphics are fast and rather bad.


I look forward to doing more complex games like this in the future. I had contemplated making an RPG instead but I decided it was too much.
